class MyRoutes {
  static String loginRoute = "/login";
  static String homeRoute = "/home";
  static String productDetailsRoute ="/product_details";
}
